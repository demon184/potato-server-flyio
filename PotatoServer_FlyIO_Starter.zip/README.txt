
Potato Server WSS Setup for Fly.io
----------------------------------
1. Make sure you have Fly.io installed: https://fly.io/docs/hands-on/install-flyctl/
2. Open a terminal and login: `flyctl auth login`
3. Deploy this folder:
   cd potato_server_flyio
   flyctl launch --name potato-server
4. Done! Use the WSS URL for your Eaglercraft client.
