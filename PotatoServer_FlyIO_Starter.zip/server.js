
// server.js - Eaglercraft WSS backend with Discord integration
const WebSocket = require("ws");
const express = require("express");
const app = express();
const port = process.env.PORT || 3000;

const wss = new WebSocket.Server({ noServer: true });
const server = app.listen(port, () => {
    console.log("WSS Server running on port", port);
});

server.on("upgrade", (req, socket, head) => {
    wss.handleUpgrade(req, socket, head, (ws) => {
        wss.emit("connection", ws, req);
    });
});

wss.on("connection", function connection(ws) {
    ws.on("message", function incoming(message) {
        // You can add custom anti-cheat here
    });
    ws.send("Welcome to Potato Server!");
});

app.get("/", (req, res) => {
    res.send("Eaglercraft WSS server is running!");
});
